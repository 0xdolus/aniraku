/**
 * Pasted secrets routinely carry a trailing newline (CI editors, dashboards).
 * An untrimmed Supabase URL silently breaks every derived URL (avatars,
 * storage, PostgREST) and fails strict shape checks — so every public env
 * value is trimmed at this single boundary. Tokens and URLs never rely on
 * significant surrounding whitespace.
 */
function cleanEnv(value: string | undefined): string {
  return value?.trim() ?? "";
}

const productionAnirakuApi = cleanEnv(process.env.EXPO_PUBLIC_API_BASE_URL) || "https://api.aniraku.tech";
const configuredMetadataResolverUrl = process.env.EXPO_PUBLIC_METADATA_RESOLVER_URL === undefined
  ? undefined
  : cleanEnv(process.env.EXPO_PUBLIC_METADATA_RESOLVER_URL);
const metadataResolverUrl = configuredMetadataResolverUrl === undefined
  ? "https://www.aniraku.tech/api/mal"
  : configuredMetadataResolverUrl.startsWith("https://")
    ? configuredMetadataResolverUrl
    : "";
const configuredTmdbEpisodesResolverUrl = process.env.EXPO_PUBLIC_TMDB_EPISODE_RESOLVER_URL === undefined
  ? undefined
  : cleanEnv(process.env.EXPO_PUBLIC_TMDB_EPISODE_RESOLVER_URL);
const tmdbEpisodesResolverUrl = configuredTmdbEpisodesResolverUrl === undefined
  ? "https://www.aniraku.tech/api/tmdb-episodes"
  : configuredTmdbEpisodesResolverUrl.startsWith("https://")
    ? configuredTmdbEpisodesResolverUrl
    : "";

function previewAnirakuProxy() {
  // Native Android has no browser window and always calls api.aniraku.tech
  // directly. Keep this module React-Native-import free because the test
  // runner evaluates it in Node before its native transform layer is present.
  // React Native defines a global window alias, but unlike a browser it has no
  // location object. Guard that distinction before Expo Router loads routes.
  const hostname = typeof window === "undefined" ? undefined : window.location?.hostname;
  if (!hostname) return null;
  if (hostname.startsWith("8081-") && hostname.endsWith(".manus.computer")) {
    return `https://${hostname.replace(/^8081-/, "3000-")}/api/aniraku`;
  }
  // Local laptop/phone testing (`expo start --web` + dev server on :3000):
  // same host, port 3000. Native Android never hits this branch.
  if (hostname === "localhost" || hostname === "127.0.0.1" || /^(192\.168\.|10\.|172\.(1[6-9]|2\d|3[01])\.)/.test(hostname)) {
    const protocol = typeof window !== "undefined" && window.location?.protocol === "https:" ? "https:" : "http:";
    return `${protocol}//${hostname}:3000/api/aniraku`;
  }
  return null;
}

export const APP_CONFIG = {
  // Android uses the authoritative production backend directly. The temporary
  // browser preview uses a same-project forwarding route because api.aniraku.tech
  // deliberately restricts its browser CORS allow-list to trusted web origins.
  apiBaseUrl: previewAnirakuProxy() ?? productionAnirakuApi,
  anilistGraphqlUrl: cleanEnv(process.env.EXPO_PUBLIC_ANILIST_GRAPHQL_URL) || "https://graphql.anilist.co",
  metadataResolverUrl,
  // This public URL reaches the website's server-side TMDB resolver. It is not
  // a TMDB API URL and the TMDB read token never enters an Expo environment.
  tmdbEpisodesResolverUrl,
  directMalEnabled: cleanEnv(process.env.EXPO_PUBLIC_DIRECT_MAL) === "true" && Boolean(cleanEnv(process.env.EXPO_PUBLIC_MAL_CLIENT_ID)),
  malClientId: cleanEnv(process.env.EXPO_PUBLIC_MAL_CLIENT_ID),
  supabaseUrl: cleanEnv(process.env.EXPO_PUBLIC_SUPABASE_URL),
  supabaseAnonKey: cleanEnv(process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY),
  deepLinkScheme: "aniraku",
} as const;

export function requirePublicConfig(value: string, name: string) {
  if (!value) throw new Error(`${name} is not configured in this build.`);
  return value;
}
