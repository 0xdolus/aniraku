import { describe, expect, it } from "vitest";
import { anirakuProxyUrl, getPlaybackType, hasExpiredEmbeddedToken, isAnirakuProxyUrl, nativePlaybackHeaders, normalizeStreamResponse, playableSources } from "../lib/aniraku-api";
import { getKnownMalId } from "../lib/anilist";
import { directSources, embedSources, episodePageCount, episodePageFor, episodePageSlice, FUTURE_RELEASE_MESSAGE, hasConfirmedPlaybackStart, isConfirmedFutureRelease, isHentaiAnime, isProxySource, nativeSources, normalizeAniSkipSegments, proxySources, shouldApplyInitialHistoryResume, shouldHoldRebufferWatermark, shouldMountReplacementSource, shouldPreferEmbed, shouldRetryProxiedSourceAfterDirect } from "../lib/watch-engine";

describe("Aniraku native playback coordination", () => {
  it("keeps only Android-safe transport headers for direct media", () => {
    // ExoPlayer forwards User-Agent when present — stripping it caused 403s
    // on UA-locked CDNs. Only transport-managed headers are blocked now.
    expect(nativePlaybackHeaders({ Referer: "https://allmanga.to/", "User-Agent": "browser", Origin: "https://example.com", Authorization: "Bearer token", Host: "cdn.example", Connection: "keep-alive" })).toEqual({ Referer: "https://allmanga.to/", "User-Agent": "browser", Origin: "https://example.com", Authorization: "Bearer token" });
  });

  it("uses the same Aniraku proxy request contract", () => {
    const proxied = anirakuProxyUrl("https://cdn.example/episode.m3u8", { Referer: "https://provider.example/", "User-Agent": "browser" });
    expect(proxied).toContain("https://api.aniraku.tech/api/v1/proxy?");
    expect(decodeURIComponent(proxied)).toContain("url=https://cdn.example/episode.m3u8");
    expect(decodeURIComponent(proxied)).toContain('headers={"Referer":"https://provider.example/","User-Agent":"browser"}');
  });

  it("never double-wraps backend pre-proxied stream URLs (403 BAD_HTTP_STATUS fix)", () => {
    const preProxied = "https://api.aniraku.tech/api/v1/proxy?url=https%3A%2F%2Fmegap.mikora.top%2Fabc%2Fmaster.m3u8&headers=%7B%22Referer%22%3A%22https%3A%2F%2Fmegaplay.buzz%2F%22%7D";
    expect(isAnirakuProxyUrl(preProxied)).toBe(true);
    expect(isAnirakuProxyUrl("https://cdn.example/episode.m3u8")).toBe(false);
    // Must play as-is, otherwise backend rejects with "proxy target not allowed".
    expect(anirakuProxyUrl(preProxied, { Referer: "https://megaplay.buzz/" })).toBe(preProxied);
  });

  it("normalizes the deployed backend skip segment fields", () => {
    const stream = normalizeStreamResponse({ sources: [], intro: { start: 47.3, end: 137.3 }, outro: { start: 1344.9, end: 1434.9 } });
    expect(stream.intro).toEqual({ startTime: 47.3, endTime: 137.3 });
    expect(stream.outro).toEqual({ startTime: 1344.9, endTime: 1434.9 });
  });

  it("classifies HLS, DASH, native, and embed media correctly", () => {
    expect(getPlaybackType({ url: "https://cdn.example/stream.m3u8" })).toBe("hls");
    expect(getPlaybackType({ url: "https://cdn.example/stream.mpd" })).toBe("dash");
    expect(getPlaybackType({ url: "https://cdn.example/stream.webm" })).toBe("native");
    expect(getPlaybackType({ url: "https://host.example/frame", type: "embed" })).toBe("embed");
    expect(getPlaybackType({ url: "https://host.example/watch/episode", type: "page" })).toBe("embed");
  });

  it("routes embed-only and Hentai titles to the embedded player", () => {
    const response = {
      sources: [
        { url: "https://embed.example/watch", type: "embed", verification: "embed" },
        { url: "https://page.example/watch", type: "page", Verification: "embed" },
        { url: "https://embed.example/dead", type: "embed", verification: "dead" },
      ],
    };
    expect(embedSources(response).map((source) => source.url)).toEqual([
      "https://embed.example/watch",
      "https://page.example/watch",
    ]);
    expect(isHentaiAnime({ isAdult: true, genres: [] })).toBe(true);
    expect(isHentaiAnime({ isAdult: false, genres: ["Action", "Hentai"] })).toBe(true);
    expect(isHentaiAnime({ isAdult: false, genres: ["Action"] })).toBe(false);
    expect(shouldPreferEmbed({ isHentai: true, directCount: 0, proxyCount: 0, embedCount: 2 })).toBe(true);
    expect(shouldPreferEmbed({ isHentai: false, directCount: 1, proxyCount: 0, embedCount: 2 })).toBe(false);
    expect(shouldPreferEmbed({ isHentai: false, directCount: 0, proxyCount: 0, embedCount: 0 })).toBe(false);
  });

  it("keeps only verified, non-expired sources", () => {
    const sources = playableSources([
      { url: "https://cdn.example/alive.m3u8", verification: "verified" },
      { url: "https://cdn.example/dead.m3u8", verification: "dead" },
      { url: "" },
      { url: "https://cdn.example/token?expires=20200101000000" },
    ]);
    expect(sources).toEqual([{ url: "https://cdn.example/alive.m3u8", verification: "verified" }]);
    expect(hasExpiredEmbeddedToken("https://cdn.example/token?expires=20200101000000")).toBe(true);
  });

  it("keeps direct and proxy sources separately eligible", () => {
    const response = {
      sources: [
        { url: "https://direct.example/720.m3u8", quality: "720p", verification: "verified" },
        { url: "https://cdn.example/720.m3u8", quality: "720p", verification: "proxy" },
        { url: "https://cdn.example/master.m3u8", quality: "Auto", Verification: "proxy" },
        { url: "https://cdn.example/1080.m3u8", quality: "1080p", verification: "proxy" },
      ],
    };
    expect(directSources(response).map((source) => source.url)).toEqual([
      "https://direct.example/720.m3u8",
    ]);
    expect(proxySources(response).map((source) => source.url)).toEqual([
      "https://cdn.example/master.m3u8",
      "https://cdn.example/1080.m3u8",
      "https://cdn.example/720.m3u8",
    ]);
    expect(nativeSources(response).map((source) => source.url)).toEqual([
      "https://direct.example/720.m3u8",
      "https://cdn.example/master.m3u8",
      "https://cdn.example/1080.m3u8",
      "https://cdn.example/720.m3u8",
    ]);
    expect(isProxySource(response.sources[1])).toBe(true);
  });

  it("never treats embed pages as native direct/proxy sources", () => {
    const response = {
      sources: [
        { url: "https://embed.example/watch", type: "embed", verification: "embed" },
        { url: "https://cdn.example/720.m3u8", quality: "720p", verification: "proxy" },
      ],
    };
    expect(directSources(response).map((source) => source.url)).toEqual([]);
    expect(proxySources(response).map((source) => source.url)).toEqual(["https://cdn.example/720.m3u8"]);
    expect(nativeSources(response).map((source) => source.url)).toEqual(["https://cdn.example/720.m3u8"]);
    expect(embedSources(response).map((source) => source.url)).toEqual(["https://embed.example/watch"]);
  });

  it("blocks confirmed future episodes and movies", () => {
    const released = [{ number: 1 }, { number: 2 }, { number: 3 }];
    expect(isConfirmedFutureRelease({ episodeNumber: 4, episodes: released, status: "RELEASING", hasConfirmedEpisodeList: true })).toBe(true);
    expect(isConfirmedFutureRelease({ episodeNumber: 3, episodes: released, status: "RELEASING", hasConfirmedEpisodeList: true })).toBe(false);
    expect(isConfirmedFutureRelease({ episodeNumber: 1, status: "NOT_YET_RELEASED" })).toBe(true);
    expect(isConfirmedFutureRelease({ episodeNumber: 1, nextAiringEpisode: { episode: 1 } })).toBe(true);
    expect(isConfirmedFutureRelease({ episodeNumber: 1, status: "FINISHED" })).toBe(false);
    expect(FUTURE_RELEASE_MESSAGE).toContain("Time travel still has not been invented");
  });

  it("uses known backend or AniList metadata IDs", () => {
    expect(getKnownMalId({ idMal: 21 })).toBe(21);
    expect(getKnownMalId({ malId: 22 })).toBe(22);
    expect(getKnownMalId({ mal_id: 23 })).toBe(23);
    expect(getKnownMalId({ myAnimeListId: 24 })).toBe(24);
    expect(getKnownMalId({ idMal: 0 })).toBeNull();
  });

  it("normalizes AniSkip v2 opening and ending payloads", () => {
    const segments = normalizeAniSkipSegments({ results: [
      { skipType: "op", interval: { startTime: 28.783, endTime: 118.783 } },
      { skipType: "ed", interval: { startTime: 1387.996, endTime: 1500 } },
    ] });
    expect(segments).toEqual({
      intro: { startTime: 28.783, endTime: 118.783, source: "aniskip" },
      outro: { startTime: 1387.996, endTime: 1500, source: "aniskip" },
    });
  });

  it("paginates high-episode-count titles", () => {
    const episodes = Array.from({ length: 1173 }, (_, index) => index + 1);
    expect(episodePageCount(episodes.length)).toBe(24);
    expect(episodePageFor(1173)).toBe(23);
    expect(episodePageSlice(episodes, 0)).toHaveLength(50);
    expect(episodePageSlice(episodes, 23)).toEqual(episodes.slice(1150));
  });

  it("preserves an already-mounted initial source during background metadata refresh", () => {
    expect(shouldMountReplacementSource(false, false)).toBe(true);
    expect(shouldMountReplacementSource(true, false)).toBe(false);
    expect(shouldMountReplacementSource(true, true)).toBe(true);
  });

  it("does not mistake a ready-but-unrendered source for successful playback", () => {
    expect(hasConfirmedPlaybackStart({ isPlaying: false, currentTime: 0, firstFrameRendered: false })).toBe(false);
    expect(hasConfirmedPlaybackStart({ isPlaying: false, currentTime: 0, firstFrameRendered: true })).toBe(true);
    expect(hasConfirmedPlaybackStart({ isPlaying: true, currentTime: 0, firstFrameRendered: false })).toBe(false);
    expect(hasConfirmedPlaybackStart({ isPlaying: false, currentTime: 1, firstFrameRendered: false })).toBe(true);
    expect(shouldRetryProxiedSourceAfterDirect(false, false)).toBe(true);
    expect(shouldRetryProxiedSourceAfterDirect(true, false)).toBe(false);
    expect(shouldRetryProxiedSourceAfterDirect(false, true)).toBe(false);
  });

  it("holds only the UI/history watermark for small non-user rebuffer rollbacks", () => {
    expect(shouldHoldRebufferWatermark({ lastStableTime: 125.5, reportedTime: 125.2, wasBuffering: true, playbackStarted: true, intentionalSeek: false })).toBe(true);
    expect(shouldHoldRebufferWatermark({ lastStableTime: 125.5, reportedTime: 125.2, wasBuffering: true, playbackStarted: true, intentionalSeek: true })).toBe(false);
    expect(shouldHoldRebufferWatermark({ lastStableTime: 125.5, reportedTime: 110, wasBuffering: true, playbackStarted: true, intentionalSeek: false })).toBe(false);
    expect(shouldHoldRebufferWatermark({ lastStableTime: 125.5, reportedTime: 125.2, wasBuffering: false, playbackStarted: true, intentionalSeek: false })).toBe(false);
  });

  it("allows a saved history position only during a fresh source start", () => {
    expect(shouldApplyInitialHistoryResume({ currentTime: 0, hasPendingResume: true, isPlaying: false, resumeAppliedForSource: false, status: "readyToPlay" })).toBe(true);
    expect(shouldApplyInitialHistoryResume({ currentTime: 0.5, hasPendingResume: true, isPlaying: true, resumeAppliedForSource: false, status: "readyToPlay" })).toBe(true);
    expect(shouldApplyInitialHistoryResume({ currentTime: 58, hasPendingResume: true, isPlaying: false, resumeAppliedForSource: false, status: "readyToPlay" })).toBe(false);
    expect(shouldApplyInitialHistoryResume({ currentTime: 0, hasPendingResume: true, isPlaying: true, resumeAppliedForSource: true, status: "readyToPlay" })).toBe(false);
  });
});
